Harmanbir Dhillon, A00994245, 1C, hdhillon68@my.bcit.ca
Jonathan Chiu, A01027608, 1C, jchiu84@my.bcit.ca
-------------------------------------------------------------
Have completed:
the log-in/log-out
Math game works correctly
Username and password saved in file called credentials.config
Website deployed to Azure
Folder named correctly
Have external style sheet
Images and css in dedicated folders
-------------------------------------------------------------
Major challenges:
Couldn't send the "+" sign through an error message
The css wasn't working properly because it had the wrong path
-------------------------------------------------------------
Azure URL
http://thebestmathgame.azurewebsites.net